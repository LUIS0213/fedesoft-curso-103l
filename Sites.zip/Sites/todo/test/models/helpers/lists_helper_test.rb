require 'test_helper'

class ListsHelperTest < ActionView::TestCase
end
