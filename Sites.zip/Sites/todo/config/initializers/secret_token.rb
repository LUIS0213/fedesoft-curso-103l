# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Listr::Application.config.secret_token = 'b566456b0ad5bc727a3349f1d1bc8589921e5817e92d43d3e837cedbf394b3ed0a4337137da6ec3cd711106528c377a7d533fe24551d6faf1e26d8f8362f5c0e'
